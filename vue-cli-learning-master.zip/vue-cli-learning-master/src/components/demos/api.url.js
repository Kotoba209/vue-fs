/**
 * Created by zh on 2018/3/21.
 */
export const USER_API = {
  getUser: '/user'
};
export const GROUP_API = {
  list: '/list'
};

export const DEMO15_API = {
  result: '/demo15/result',
  detail: '/demo15/detail'
};
