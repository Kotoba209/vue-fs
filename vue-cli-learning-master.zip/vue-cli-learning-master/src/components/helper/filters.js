/**
 * Created by zh on 2018/11/12.
 */
const capitalize1st = value => value.charAt(0).slice(0, 1).toUpperCase() + value.slice(1);

export default {
  capitalize1st
}
