/**
 * Created by zh on 2018/3/21.
 */
import Mock from 'mockjs'

Mock.setup({
  timeout: '100-500'
});
