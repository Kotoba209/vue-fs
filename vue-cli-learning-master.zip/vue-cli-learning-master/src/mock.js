/**
 * Created by zh on 2018/3/21.
 */
import './mock.config';

import './components/demos/demo9/mock';
import './components/demos/demo15/mock';
